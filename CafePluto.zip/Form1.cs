namespace CafePluto
{
    public partial class Form1 : Form
    {
        int harga;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selected = this.comboBox1.GetItemText(this.comboBox1.SelectedItem);
            if (selected == "Espresso")
            {
                harga += 10000;
            }
            else if (selected == "Latte")
            {
                harga += 15000;
            }
            else if (selected == "Cappucino")
            {
                harga += 12000;
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click_1(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            harga += 3000;
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            harga += 2500;
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            harga += 1000;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            MessageBox.Show(harga.ToString());
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            harga += 3000;

        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            harga += 3500;
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            harga += 1500;
        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            harga += 2000;
        }
    }
}